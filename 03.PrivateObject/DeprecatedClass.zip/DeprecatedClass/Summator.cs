﻿namespace DeprecatedClass
{
    public class Summator
    {
        private int GetSum(int a, int b)
        {
            return a + b;
        }
    }
}
